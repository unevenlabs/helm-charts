# Changelog

All notable changes to this module will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [30.52.0] - 2026-25-03
### Changed
- Add support to create a custom service account for Clickhouse

## [30.51.0] - 2026-25-03
### Changed
- Add support to pass config file to Clickhouse

## [30.50.0] - 2024-18-03
### Changed
- Make virtualservices a list

## [30.49.0] - 2024-12-06
### Changed
- Added clickhouse user_defined_function.xml taken from https://github.com/PostHog/posthog/blob/master/docker/clickhouse/user_defined_function.xml

## [30.48.0] - 2024-12-06
### Changed
- Added properties-defs-rs deployment

## [30.47.0] - 2024-11-12
### Changed
- Adapt for Unevenlabs

## [30.46.0] - 2024-11-12
### Changed
- Initial clone from https://github.com/PostHog/charts-clickhouse.git
